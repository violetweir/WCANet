# Copyright (c) OpenMMLab. All rights reserved.
from .bert import BertModel

__all__ = ['BertModel']
